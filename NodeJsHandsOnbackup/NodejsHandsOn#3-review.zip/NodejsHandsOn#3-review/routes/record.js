const express = require("express");
const routerRecord = express.Router();
let dataRecord = [
  {
    id: 1,
    img: "https://steadfastmall.com/wp-content/uploads/2021/09/apple_iphone_13_pro_max_graphite_steadfast.png",
    name: "Iphone 13 Pro Max",
    specification:
      "Super Retina XDR OLED, 120Hz, HDR10, Dolby Vision, 1000 nits (HBM), 1200 nits (peak)",
    author: "Diego Laura",
  },
  {
    id: 2,
    img: "https://res.cloudinary.com/dpfl37yun/image/upload/v1632982202/iphone_13_blue_1_43d1a46a9b.png",
    name: "Iphone 13",
    specification:
      "Super Retina XDR OLED, HDR10, Dolby Vision, 800 nits (HBM), 1200 nits (peak",
    author: "Long Laan",
  },
  {
    id: 3,
    img: "https://fscl01.fonpit.de/devices/87/2287-w320h320.png",
    name: "Iphone 13 mini",
    specification:
      "	Super Retina XDR OLED, HDR10, Dolby Vision, 800 nits (HBM), 1200 nits (peak)",
    author: "Agap-ito Bagumbayan",
  },
  {
    id: 4,
    img: "https://www.thekase.com/on/demandware.static/-/Sites-tk-product/default/dwd215f158/38936042/130483_medium.png",
    name: "Iphone SE",
    specification: "Retina IPS LCD, 625 nits (typ)",
    author: "Taga-Ilog",
  },
  {
    id: 5,
    img: "https://www.galleonent.com/image/cache/catalog/Phone%20Images/iphone%2013/iphone-13-black-1000x1000.png",
    name: "Iphone XS",
    specification: "Super Retina OLED, HDR10, Dolby Vision, 625 nits (HBM)",
    author: "Dimas-ilaw",
  },
];

routerRecord.get("/", (req, res) => {
  res.render("record", { data: dataRecord });
  //res.status(201).json(dataRecord);
});

//get by id
routerRecord.get("/:id", (req, res) => {
  //find items by id
  let check = dataRecord.find((item) => {
    return item.id === parseInt(req.params.id);
  });
  //verify the data by id
  if (check) {
    //res.status(201).json(check);
    res.render("view", { record: check });
  } else {
    res.status(404).send("ID not found!");
  }
});

//add new record
routerRecord.post("", (req, res) => {
  let body = req.body;
  //let id = +req.params.id;
  dataRecord.push(body);
  console.log(dataRecord);
  res.redirect("record");
  //res.status(201).json(body);
});
module.exports = routerRecord;

routerRecord.get("/update/:id", (req, res) => {
  let check = dataRecord.find((item) => {
    return parseInt(item.id) === parseInt(req.params.id);
  });
  if (check) {
    res.render("edit", { record: check });
  } else {
    res.status(404).send("ID not found!");
  }
});

routerRecord.put("/update/:id", (req, res) => {
  let id = +req.params.id;
  let body = req.body;
  let index = dataRecord.findIndex((df) => parseInt(df.id) === parseInt(id));

  if (index >= 0) {
    let updateData = { id: id, ...body };
    dataRecord[index] = updateData;
    res.redirect("/record");
  } else {
    res.status(404).send("Id does not exist");
  }
});

routerRecord.delete("/:id", (req, res) => {
  let id = +req.params.id;
  let index = dataRecord.findIndex((df) => parseInt(df.id) === parseInt(id));
  if (index >= 0) {
    dataRecord.splice(index, 1);
    res.redirect("/record");
  } else {
    res.status(404).send("ID not found");
  }
});
