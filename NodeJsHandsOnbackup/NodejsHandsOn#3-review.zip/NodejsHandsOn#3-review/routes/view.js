const express = require('express');
const routerView = express.Router();

routerView.get('/', (req, res)=>{
    res.render('view', {test:'Ejs is working and waving 👋'});
});

module.exports = routerView;