const express = require('express');
const routerGallery = express.Router();

routerGallery.get('/', (req, res)=>{
    res.render('gallery', {test:'Ejs is working and waving 👋'});
});
module.exports = routerGallery;