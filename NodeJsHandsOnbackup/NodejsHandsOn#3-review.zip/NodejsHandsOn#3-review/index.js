//import
const express = require("express");
const bodyParser = require("body-parser");
const methodOveride = require("method-override");
const routerHome = require("./routes/home");
const routerAbout = require("./routes/about");
const routerGallery = require("./routes/gallery");
const routerRecord = require("./routes/record");
const routerView = require("./routes/view");
const app = express();
//static file
app.use(express.static("public"));
app.use(methodOveride("_method"));
app.use("/style", express.static(__dirname + "public/css"));
app.use("/js", express.static(__dirname + "public/js"));
app.use("/img", express.static(__dirname + "public/img"));

//middleware
app.use(express.json());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
//routes
app.use("/home", routerHome);
app.use("/record", routerRecord);
app.use("/about", routerAbout);
app.use("/gallery", routerGallery);
app.use("/view", routerView);
app.get("/", (req, res) => {
  res.render("home", { test: "Ejs is working and waving 👋" });
});
// frontend sepup/ views
app.set("views", "./views");
app.set("view engine", "ejs");

//test ejs

//check connection for our server
const port = 8080;
app.listen(port, () => {
  console.log(`The server is now running in the port: change ${port}`);
});
